import {Component} from '@angular/core';

@Component({
    selector: 'app-practice-component',
    templateUrl: './practice.component.html',
    styleUrls: ['./practice.component.scss']
})
export class PracticeComponent {
    slajdovi: any = [
        '../../../../assets/img/pics/DSCF6358.jpg',
        '../../../../assets/img/pics/DSCF6382.jpg',
        '../../../../assets/img/pics/DSCF6391.jpg',
        '../../../../assets/img/pics/DSCF6334.jpg',
        '../../../../assets/img/pics/DSCF6327.jpg'
    ];
}
