import {Component} from '@angular/core';

@Component({
    selector: 'app-phylosopht-component',
    templateUrl: './phylosophy.component.html',
    styleUrls: ['./phylosophy.component.scss']
})
export class PhylosophyComponent {
    slajdovi: any = [
        '../../../../assets/img/pics/DSCF6462.jpg',
        '../../../../assets/img/pics/DSCF6494.jpg',
        '../../../../assets/img/pics/_XT22856.jpg',
        '../../../../assets/img/pics/DSCF6705.jpg',
        '../../../../assets/img/pics/DSCF6722.jpg',
        '../../../../assets/img/pics/DSCF6406.jpg'
    ];
}
