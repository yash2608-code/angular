import {Component} from '@angular/core';

@Component({
    selector: 'app-testmonials-component',
    templateUrl: './testmonials.component.html',
    styleUrls: ['./testmonials.component.scss']
})
export class TestmonialsComponent {
}
