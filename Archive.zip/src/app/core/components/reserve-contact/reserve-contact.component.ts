import {Component} from '@angular/core';

@Component(
    {
        selector: 'app-reserve-contact',
        templateUrl: 'reserve-contact.component.html',
        styleUrls: ['./reserve-contact.component.scss']
    }
)
export class ReserveContactComponent {
}
